﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineSurvey
{
    public partial class CaptureSurvey : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                    survey objAdd = new survey();

                    objAdd.addSurvey(Convert.ToString(txtSurname.Text), Convert.ToString(txtFName.Text), Convert.ToString(txtContact.Text), Convert.ToDateTime(txtDate.Text),
                        Convert.ToInt32(txtAge.Text), 3, 3, 4);
                    //lblError.Text = "User Added Successfully!";
            }
            catch
            {

            }
        }
    }
}