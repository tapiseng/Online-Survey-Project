﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace OnlineSurvey
{
    public partial class SurveyResults : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

            survey obj1 = new survey();

            DataTable dt = obj1.surveyResults().Tables[0];

                //Binding TextBox From dataTable 
                if (dt.Rows.Count > 0)
                {
                    lbl_total_num_survey.Text = dt.Rows[0]["number_of_survey"].ToString();
                    lbl_average_age.Text = dt.Rows[0]["average_age"].ToString();
                    lbl_max_age.Text = dt.Rows[0]["max_age"].ToString();
                    lbl_min_age.Text = dt.Rows[0]["min_age"].ToString();

                    lbl_Pizza.Text = dt.Rows[0]["Pizza"].ToString();
                    lbl_Pasta.Text = dt.Rows[0]["Pasta"].ToString();
                    lbl_pap_wors.Text = dt.Rows[0]["pap_wors"].ToString();
                

                }
                CSconn.conn.Close();
            }
            catch 
            {
              
            }
       
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}