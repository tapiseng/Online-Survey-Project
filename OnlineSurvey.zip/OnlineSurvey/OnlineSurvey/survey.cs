﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace OnlineSurvey
{
    public class survey
    {
        //Declare variable
        private DataTable dtIntervention;
        private DataSet ds;
        CSconn newConn = new CSconn();

        public void addSurvey(string surname, string fname, string contact, DateTime date, int age,
            int favouritefood, int rating, int entertainment)
        {
            try
            {
                newConn.DBConn();
                //Instantiate variable
                SqlCommand com = new SqlCommand();
                com.Connection = CSconn.conn;

                com.CommandText = "sp_addsurvey";
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@surname", surname);
                com.Parameters.AddWithValue("@fname", fname);
                com.Parameters.AddWithValue("@contact", contact);
                com.Parameters.AddWithValue("@date", date);
                com.Parameters.AddWithValue("@age", age);

                com.Parameters.AddWithValue("@favouritefood", favouritefood);
                com.Parameters.AddWithValue("@rating", rating);
                com.Parameters.AddWithValue("@entertainment", entertainment);
                com.ExecuteNonQuery();
                CSconn.conn.Close();
            }
            catch
            {

            }
        }


        public DataSet surveyResults()
        {
            try
            {
                newConn.DBConn();
                //Instantiate variable
                SqlCommand com = new SqlCommand();
                com.Connection = CSconn.conn;
                SqlDataAdapter adapter = new SqlDataAdapter();
                ds = new DataSet();

                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sp_surveyresults";
                //com.Parameters.AddWithValue("@", Parameter);
                adapter = new SqlDataAdapter(com);
                adapter.Fill(ds);
                CSconn.conn.Close();
            }
            catch
            {

            }
            return ds;
        }

    }
}