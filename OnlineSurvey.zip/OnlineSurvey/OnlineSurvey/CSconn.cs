﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace OnlineSurvey
{
    public class CSconn
    {
        public static SqlConnection conn = null;
        public void DBConn()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myConnString"].ConnectionString);
            conn.Open();
        }
    }
}